const chatMessages = document.getElementById("chat-messages");
const chatInput = document.getElementById("chat-input");
const sendButton = document.getElementById("send-button");

sendButton.addEventListener("click", sendMessage);
chatInput.addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        sendMessage();
    }
});

function sendMessage() {

    const message = chatInput.value.trim();

    if (message === "") return;

    renderUserMessage(message);

    chatInput.value = "";

    fetch("/api/chat", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {

        renderHabitatMessage(data.response);

    });

}

function renderUserMessage(message) {

    const messageElement = document.createElement("div");
    messageElement.className = "message user-message";

    messageElement.innerHTML = `
        <div class="message-label">You</div>
        <div class="message-content">${message}</div>
    `;

    chatMessages.appendChild(messageElement);

    scrollToBottom();
}

function renderHabitatMessage(message) {

    const messageElement = document.createElement("div");
    messageElement.className = "message habitat-message";

    messageElement.innerHTML = `
        <div class="message-label">Habitat</div>
        <div class="message-content">${message}</div>
    `;

    chatMessages.appendChild(messageElement);

    scrollToBottom();
}

function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}