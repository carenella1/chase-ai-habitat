(function(){

const container = document.getElementById("agent-ecosystem")

const canvas = document.createElement("canvas")
container.appendChild(canvas)

const ctx = canvas.getContext("2d")

let width
let height

function resize()
{
width = canvas.width = container.clientWidth
height = canvas.height = container.clientHeight
}

window.addEventListener("resize",resize)
resize()

/* AGENTS */

const agents = [
{name:"Insight",x:200,y:200,vx:0,vy:0,color:"#00eaff"},
{name:"Curiosity",x:300,y:250,vx:0,vy:0,color:"#33ffcc"},
{name:"Research",x:400,y:300,vx:0,vy:0,color:"#ffaa33"},
{name:"Explorer",x:500,y:260,vx:0,vy:0,color:"#ff66cc"},
{name:"Curator",x:600,y:220,vx:0,vy:0,color:"#66aaff"},
{name:"Strategist",x:700,y:260,vx:0,vy:0,color:"#ffcc66"},
{name:"Builder",x:750,y:330,vx:0,vy:0,color:"#33ffaa"},
{name:"Archivist",x:820,y:380,vx:0,vy:0,color:"#ffaaee"}
]


function drift(agent)
{
agent.vx += (Math.random()-0.5)*0.05
agent.vy += (Math.random()-0.5)*0.05

agent.vx *= 0.95
agent.vy *= 0.95
}

function update()
{

agents.forEach(a=>{

drift(a)

a.x += a.vx
a.y += a.vy

/* keep agents inside box */

if(a.x < 20) a.x = 20
if(a.x > width-20) a.x = width-20
if(a.y < 20) a.y = 20
if(a.y > height-20) a.y = height-20

})

}

function draw()
{

ctx.clearRect(0,0,width,height)

/* draw connections */

for(let i=0;i<agents.length-1;i++)
{

const a = agents[i]
const b = agents[i+1]

ctx.beginPath()
ctx.moveTo(a.x,a.y)
ctx.lineTo(b.x,b.y)

ctx.strokeStyle = "#00eaff"
ctx.lineWidth = 2
ctx.stroke()

}

/* draw agents */

agents.forEach(a=>{

ctx.beginPath()
ctx.arc(a.x,a.y,10,0,Math.PI*2)

ctx.fillStyle = a.color
ctx.fill()

})

}

function loop()
{
update()
draw()
requestAnimationFrame(loop)
}

loop()

})()