(function(){

const ecosystemCanvas = document.createElement("canvas")
ecosystemCanvas.id = "ecosystem-layer"
document.body.appendChild(ecosystemCanvas)

const ctx = ecosystemCanvas.getContext("2d")

let width
let height

function resize()
{
    width = ecosystemCanvas.width = window.innerWidth
    height = ecosystemCanvas.height = window.innerHeight
}

window.addEventListener("resize", resize)
resize()


/* AGENT ORGANISMS */

const agents = [
{ name:"InsightAgent",x:200,y:300,vx:0,vy:0,color:"#00eaff",energy:0 },
{ name:"ExplorerAgent",x:400,y:200,vx:0,vy:0,color:"#33ffcc",energy:0 },
{ name:"StrategistAgent",x:700,y:350,vx:0,vy:0,color:"#ffaa33",energy:0 },
{ name:"BuilderAgent",x:900,y:250,vx:0,vy:0,color:"#ff66cc",energy:0 },
{ name:"CuratorAgent",x:600,y:150,vx:0,vy:0,color:"#66aaff",energy:0 }
]


/* IDEA ORGANISMS */

const ideas = []

function spawnIdea(label)
{
ideas.push({
label:label,
x:Math.random()*width,
y:Math.random()*height,
energy:1
})
}


/* DRIFT */

function drift(agent)
{
agent.vx += (Math.random()-0.5)*0.05
agent.vy += (Math.random()-0.5)*0.05

agent.vx *= 0.98
agent.vy *= 0.98
}


/* STEERING */

function steer(agent)
{
if(!agent.target) return

let dx = agent.target.x-agent.x
let dy = agent.target.y-agent.y

let dist = Math.sqrt(dx*dx+dy*dy)

if(dist < 10)
{
agent.target = null
return
}

agent.vx += dx*0.001
agent.vy += dy*0.001
}


/* UPDATE */

function update()
{
agents.forEach(a=>{

drift(a)
steer(a)

a.x += a.vx
a.y += a.vy

if(a.energy > 0)
a.energy *= 0.9
})


agents.forEach(a=>{

if(ideas.length>0 && Math.random()<0.01)
{
const idea = ideas[Math.floor(Math.random()*ideas.length)]

a.target={
x:idea.x,
y:idea.y
}
}

})
}


/* DRAW */

function draw()
{
ctx.clearRect(0,0,width,height)


ideas.forEach(i=>{

let radius = 6 + i.energy*4

ctx.beginPath()
ctx.arc(i.x,i.y,radius,0,Math.PI*2)

ctx.fillStyle="#ffaa33"
ctx.fill()

ctx.shadowBlur=15
ctx.shadowColor="#ffaa33"

i.energy*=0.98

})


agents.forEach(a=>{

let radius = 10 + a.energy*8

ctx.beginPath()
ctx.arc(a.x,a.y,radius,0,Math.PI*2)

ctx.fillStyle=a.color
ctx.fill()

ctx.shadowBlur=30*a.energy
ctx.shadowColor=a.color

})
}


/* LOOP */

function loop()
{
update()
draw()
requestAnimationFrame(loop)
}

loop()


/* COGNITION EVENTS */

async function fetchCognitionEvents()
{
try{

const response = await fetch("/api/cognition_events")
const data = await response.json()

data.events.forEach(e=>{

const agent = agents.find(a =>
a.name.toLowerCase().includes(e.agent.toLowerCase())
)

if(agent)
{
agent.energy = 1

agent.target={
x:Math.random()*width,
y:Math.random()*height
}
}

if(e.action.includes("discovery") || e.action.includes("insight"))
{
spawnIdea(e.action)
}

})

}
catch(err)
{
console.log("event fetch failed",err)
}
}

setInterval(fetchCognitionEvents,3000)

})()