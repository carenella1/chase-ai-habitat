function updateAgents(activity)
{
    const agents =
    [
        "insight",
        "researcher",
        "explorer",
        "curator",
        "strategist",
        "builder",
        "idea",
        "archivist"
    ]

    agents.forEach(a =>
    {
        const el = document.getElementById("agent-" + a)
        if(el) el.classList.remove("active")
    })

    activity.forEach(entry =>
    {
        const text = entry.toLowerCase()

        agents.forEach(agent =>
        {
            if(text.includes(agent))
            {
                const el = document.getElementById("agent-" + agent)
                if(el) el.classList.add("active")
            }
        })
    })
}


function updateThreads(activity)
{
    const container = document.getElementById("research-threads")
    container.innerHTML = ""

    const threads = activity.filter(a =>
        a.toLowerCase().includes("research thread")
    )

    threads.forEach(t =>
    {
        const el = document.createElement("div")
        el.className = "thread"
        el.innerText = t
        container.appendChild(el)
    })
}


async function updateHabitat()
{
    const response = await fetch("/api/habitat/status")
    const data = await response.json()

    document.getElementById("cycle-count").innerText = data.cycle_count
    document.getElementById("cycle-status").innerText = data.last_status

    const consoleElement = document.getElementById("console")
    consoleElement.innerHTML = ""

    data.recent_activity.forEach(entry =>
    {
        const line = document.createElement("div")
        line.className = "console-line"
        line.innerText = entry
        consoleElement.appendChild(line)
    })

    updateAgents(data.recent_activity)
    updateThreads(data.recent_activity)
}

async function loadCognitionFeed() {

    try {

        const response = await fetch("/cognition");
        const data = await response.json();

        const container = document.getElementById("cognition-feed");

        if (!container) return;

        container.innerHTML = "";

        data.entries.slice(0, 20).forEach(entry => {

            const item = document.createElement("div");
            item.className = "cognition-entry";

            item.innerHTML = `
                <div class="cognition-agent">${entry.agent}</div>
                <div class="cognition-type">${entry.type}</div>
                <div class="cognition-content">${entry.content}</div>
                <div class="cognition-reasoning">${entry.reasoning || ""}</div>
                <div class="cognition-confidence">
                    confidence: ${entry.confidence ?? "n/a"}
                </div>
            `;

            container.appendChild(item);
        });

    } catch (error) {

        console.warn("Cognition feed unavailable:", error);

    }

}

setInterval(loadCognitionFeed, 2000);

updateHabitat()

setInterval(updateHabitat,3000)